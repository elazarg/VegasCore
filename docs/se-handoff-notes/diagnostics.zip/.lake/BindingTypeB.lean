/- Copyright (c) 2026 VegasCore contributors. All rights reserved. -/

import Vegas.Game.SourceServiceActiveBindingCheckpoint
import Vegas.Game.SourceServiceTimedReachability
import Vegas.Pending.ReactiveResponseConditioning

/-! # The source continuation selected by a native binding response

A current response conditions the source value and the independent submission
time. Every subsequent source event is executed by the same timed baseline.
The resulting law retains the complete source terminal state.
-/

noncomputable section

namespace Vegas.SourceProgram.RevealService

open GameTheory.Math.Probability Interaction EventGraphRuntime EventLowering

variable {Player : Type} [DecidableEq Player] [Fintype Player]
  {L : IExpr} [IExpr.ResultTypes L]

/-- The complete source law following one legal unsent binding response.
All later native execution is evaluated, and its source correspondence is
derived from the actual fully mixed prefix, not supplied as a comparison
hypothesis. Conditioning may retain the timing tag; terminal source behavior
depends only on its typed binding value. -/
theorem sourceServiceTimedPolicy_binding_response_continuation
    (setup : Setup (Player := Player) (L := L))
    (leaks : MessageNetwork.ObservationRule Player (WitnessedPacket (graph setup)))
    (bounds : MessageBounds (graph setup)) (values : bounds.CoversBindingValues)
    (initialValues : ∀ state ∈ (initialLaw setup).support, bounds.CandidateValues state)
    (capacity : (graph setup).order.eventCount ≤ bounds.candidateCount)
    (rosters : (graph setup).EventId → List Player)
    (opportunities : ∀ event actor payload,
      (graph setup).outputLayout event = .binding actor payload → actor ∈ rosters event)
    (timing : ∀ event who, (graph setup).actor? event = some who →
      FinDist (Fin ((rosters event).count who)))
    (full : ∀ event who owned, (timing event who owned).FullSupport)
    (network : (runtime setup).NetworkPolicy leaks)
    (wholeProfile : BehavioralProfile setup.program)
    (permitted : ∀ who, (wholeProfile who).Admitted setup.program
      (CommitmentInterface.values setup.program))
    (effective : ∀ who, (wholeProfile who).EffectiveDisclosures setup.program []
      (Revelations.initial setup.context))
    (covered : ∀ who, (sourceServiceMenu setup leaks bounds rosters).Admissible
      (initialLaw setup) (rosterPlan setup rosters).length
      (rosterScheduler setup leaks rosters network) who
      (sourceServiceTimedPolicy setup leaks rosters timing wholeProfile who))
    (assessment : ((sourceServiceMenu setup leaks bounds rosters).information
      (initialLaw setup) (rosterPlan setup rosters).length
      (rosterScheduler setup leaks rosters network)).BehavioralAssessment)
    (strategy : assessment.strategy = fun who =>
      (sourceServiceMenu setup leaks bounds rosters).restrictPolicy (initialLaw setup)
        (rosterPlan setup rosters).length (rosterScheduler setup leaks rosters network) who
          (sourceServiceTimedPolicy setup leaks rosters timing wholeProfile who))
    (mixed : assessment.IsFullyMixed)
    {Γ : SourceCtx Player L} {openNames : Finset VarId}
    {name : VarId} {owner : Player} {payload : L.Ty}
    (fresh : name ∉ Γ.map Prod.fst) (guard : SourceGuard L Γ owner name payload)
    (next : SourceProgram Player L ((name, .commitment owner payload) :: Γ)
      (insert name openNames))
    (profile : BehavioralProfile (.commit name owner fresh guard next))
    (refs : ContextRefs (graphLayout setup.program) Γ) (source : Config Player L Γ)
    (embedding : OutputEmbedding (inputLayout setup.context) (outputLayout setup.program)
      (.commit name owner fresh guard next))
    (refsBefore : ContextRefsBefore refs embedding) (rank : Nat)
    (aligned : CompiledPolicySuffix setup.program wholeProfile
      (.commit name owner fresh guard next) profile
      refs source.revelations source.registry embedding refsBefore rank)
    (execution : (application setup leaks).Execution) (remainingFuel : Nat)
    (trace : ((sourceServiceMenu setup leaks bounds rosters).protocol (initialLaw setup)
      (rosterPlan setup rosters).length (rosterScheduler setup leaks rosters network)).Trace
        (some ⟨remainingFuel, some owner, execution⟩))
    (agree : refs.Agrees source.state execution.application.config.store)
    (history : decodeHistory setup.program
      (execution.application.config.history.map
        (setup.eventGraph.fromModeCompletion .sequential)) = source.history)
    (serial : Nat)
    (freshSlot : reactiveFreshSlot (execution.observe
      (application setup leaks) owner).application = some serial)
    (candidate : execution.application.candidates.lookup (owner, .prepared serial) = .fresh)
    (remaining : List Player) (before : List (ServiceInstruction (graph setup))) :
    let index : Fin (eventCount (.commit name owner fresh guard next)) :=
      ⟨0, by simp [eventCount]⟩
    let event : (graph setup).EventId := embedding.event index
    ∀ (outputEq : (graph setup).outputLayout event = .binding owner payload)
      (owned : (graph setup).actor? event = some owner)
      (granted : execution.application.serviceGrant = some event)
      (unsent : (runtime setup).eventRecorded leaks (execution.recall owner) event = false)
      (counted : (execution.recall owner).length + 1 + remaining.count owner =
        rosterOffset setup rosters owner event + (rosters event).count owner)
      (ready : execution.application.config.cut.Ready event)
      (timely : execution.application.WithinDeadline (runtime setup) event)
      (vacant : execution.application.accepted (.inr event) = none)
      (unused : execution.application.HandleUnused (owner, .prepared serial))
      (serials : execution.network.SerialsBeforeNext)
      (published : execution.network.Satisfies fun message =>
        message.id ∈ execution.network.ledger.map Message.id),
    let app := application setup leaks
    let players := sourceServiceTimedPolicy setup leaks rosters timing wholeProfile
    let phase := remaining.map ServiceInstruction.player ++
      (.includeLatest event owner :: List.replicate (event.val + 1) .tick ++ [.expire event])
    let later := ((List.finRange (graph setup).order.eventCount).drop (event.val + 1)).flatMap
      (rosterBlock setup rosters)
    ∀ (split : rosterPlanPrefix setup rosters (event.val + 1) =
        before ++ .player owner :: phase)
      (position : execution.environmentRecall.length = before.length + 1)
      (response : app.Action)
      (allowed : response ∈ (sourceServiceMenu setup leaks bounds rosters).actions owner
        (execution.recall owner) (execution.observe app owner)),
    True := by
  simp only

end Vegas.SourceProgram.RevealService

