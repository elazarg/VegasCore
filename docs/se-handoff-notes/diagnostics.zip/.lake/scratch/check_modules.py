from pathlib import Path
import subprocess, json, sys, tomllib
base=json.loads(Path('.lake/scratch/Vegas.Pending.ReactiveBindingLikelihood.setup.json').read_text(encoding='utf-8-sig'))
def flatten(options, prefix=''):
    result = {}
    for key, value in options.items():
        name = prefix + key
        if isinstance(value, dict):
            result.update(flatten(value, name + '.'))
        else:
            result[name] = value
    return result
base['options'] = flatten(tomllib.loads(Path('lakefile.toml').read_text())['leanOptions'])
for module in sys.argv[1:]:
    base['name']=module
    setup=Path('.lake/scratch/'+module+'.setup.json')
    setup.write_text(json.dumps(base))
    assert json.loads(setup.read_text())['name']==module
    print('CHECK '+module,flush=True)
    result=subprocess.run(['lake','env','lean',module.replace('.','/')+'.lean',
        '--setup',str(setup),'-o','.lake/build/lib/lean/'+module.replace('.','/')+'.olean'])
    if result.returncode: sys.exit(result.returncode)
